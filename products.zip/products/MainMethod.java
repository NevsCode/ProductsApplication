
package products;


public class MainMethod {
    
  
    public static void main(String[] args)
    {
        // calling the prodtuct class to display my applittion
       Products product = new Products();  
       Products.Display();
       
    }
    
}
